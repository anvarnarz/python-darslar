"""
10/02/2021

Dasturlash asoslari

#33-DARS. FILES

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

#!!! Quyidagi usul tavsiya qilinmaydi
file = open('pi.txt')
PI = file.read()
print(PI)
file.close()