"""
08/01/2021

Dasturlash asoslari

"SON TOPISH" O'YINI

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

import funksiyalar as f

print("Keling o'ylagan sonni topish o'ynaymiz!")
f.play(10)