print("Hello World)
