"""
29/03/2021

Dasturlash asoslari

15-DARS: To'plamlar

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

# To'plam yaratish
sonlar = {1,2,3}
ismlar = {'alijon','valijon','boqijon'}
mevalar = set()
sonlar = {1,2,3,3,4,4,5,6}
print(sonlar)

# Ro'yxatdan to'plamga o'tish
mevalar = ['olma','anjir','olma','uzum','olma','uzum']
mevalar = set(mevalar)
print(mevalar)