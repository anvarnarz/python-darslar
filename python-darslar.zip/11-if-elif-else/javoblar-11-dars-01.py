"""
25/11/2020

Dasturlash asoslari

#11-dars: if-elif-else

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

son = float(input("Juft son kiriting: "))
if son%2!=0:
    print('Bu son juft emas.')
else:
    print("Rahmat!")