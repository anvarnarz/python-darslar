print("\"Nexia\", \"Tico\", 'Damas' ko'rganlar qilar havas")
#1 5 ning 4-darajasi
print('5 ning 4-darajasi', 5**4)
#2 22 ni 4 ga bo'lganda qancha qoldiq qoladi?
print("22 ni 4 ga bo'lganda qancha qoldiq", 22%4)
#3 Tomonlari 125 ga teng kvadratning yuzi va perimetrini toping
print("Tomonlari 125 ga teng kvadratning yuzi", 125*125, "ga, perimetri", 4*125, "teng")
#4 Diametri 12 ga teng bo'lgan doiraning yuzini toping
print('Diametri 12 ga teng bo\'lgan doiraning yuzi', 3.14*(12/2)**2, 'ga teng')
#5 Katetlari 6 va 7 bo'lgan to'g'ri burchakli uchburchakning gipotenuzasini toping
print("Katetlari 6 va 7 bo'lgan to'g'ri burchakli uchburchakning gipotenuzasi", (6**2+7**2)**(1/2))