"""
7/11/2020

Dasturlash asoslari

#04-dars: Oz'garuvchilar

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

# "Hello World!" matnini yangi o'zgaruvchiga yuklang va print() yordamida konsolga chiqaring
matn = "Hello World!"
print(matn)

# xabar deb nomlangan o'zgaruvchiga biror matn yuklang va konsolga chiqaring, keyin esa o'zgaruvchiga yangi qiymat berib uni ham konsolga chiqaring.
xabar = "Assalom alaykum"
print(xabar)

# class den nomlangan o'zgaruvchi yarating, unga biror qiymat bering va konsolga chiqaring (siz kutgan natija chiqdimi?)
# O'zgaruvchini class deb nomlash mumkin emas, sababi class bu maxsus kalit so'z.

#Quyidagi kodni bajaring
radius = 5
pi = 3.14159
aylana_yuzi = pi * radius**2
print("Radiusi" , radius, "ga teng aylananing yuzi=", aylana_yuzi)